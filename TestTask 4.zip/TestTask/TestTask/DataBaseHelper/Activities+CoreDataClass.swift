//
//  Activities+CoreDataClass.swift
//  
//
//  Created by Sourabh Jaiswal on 01/10/21.
//
//

import Foundation
import CoreData

@objc(Activities)
public class Activities: NSManagedObject {

}
