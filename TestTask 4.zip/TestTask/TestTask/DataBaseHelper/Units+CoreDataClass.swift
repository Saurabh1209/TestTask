//
//  Units+CoreDataClass.swift
//  TestTask
//
//  Created by Sourabh Jaiswal on 01/10/21.
//  Copyright © 2021 Saurabh Jaiswal. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Units)
public class Units: NSManagedObject {

}
