//
//  ViewController.swift
//  TestTask
//
//  Created by Sourabh Jaiswal on 30/09/21.
//  Copyright © 2021 Saurabh Jaiswal. All rights reserved.
//

import UIKit
import SwiftyJSON

class ViewController: UIViewController {
    
    var modelObj = [BuildingBlockModel]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }

    
   

}

